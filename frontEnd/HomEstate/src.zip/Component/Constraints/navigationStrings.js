export default{
    HOME:'Home',
    BUY:'Buy',
    SELL:'Sell',
    TABS:'BottomTabs',
    CONTACT:'ContactUs',
    LOGOUT:'Log Out',

}