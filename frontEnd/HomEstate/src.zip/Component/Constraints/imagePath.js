export default{
    logo:require('../../Asset/Images/logo.png'),
    icHome:require('../../Asset/Images/icon/home.png'),
    icBuy:require('../../Asset/Images/icon/cart.png'),
    icSell:require('../../Asset/Images/icon/sell.png'),
    icHome2x:require('../../Asset/Images/icon/home2x.png'),
    icBuy2x:require('../../Asset/Images/icon/cart2x.png'),
    icSell2x:require('../../Asset/Images/icon/sell2x.png'),
    house1:require('../../Asset/Images/house1.png'),
    house2:require('../../Asset/Images/house2.png'),
    house3:require('../../Asset/Images/house3.png'),
    
}