import * as React from 'react';
import { Button, View, Image, Text, StyleSheet } from 'react-native';
import Routes from './Navigation/Routes';


export default function MainPage() {
 
  return (<>
         <Routes />    
    
    </>
  );
}