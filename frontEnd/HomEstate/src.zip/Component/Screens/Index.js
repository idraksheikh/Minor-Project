export {default as Home} from './Home/Home';
export {default as Buy} from './Buy/Buy';
export {default as Sell} from './Sell/Sell';