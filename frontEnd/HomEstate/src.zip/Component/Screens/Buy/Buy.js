import * as React from 'react';
import { Button, View, Image, Text,StyleSheet,Alert } from 'react-native';
import navigationStrings from '../../Constraints/navigationStrings';
import Header from '../Header';
import Tiles from './Tiles';


  
 export default function Buy({ navigation }) {
   const logout=()=>{
    Alert.alert(
      "Log Out",
      "Are you sure you want to logout.",
      [
        {
          text: "No",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        { text: "Yes", onPress: () => {navigation.navigate('Login');} }
      ]
    );
   }
    return (<>
      <Header/>
      <Button title='LogOut' onPress={logout}/> 
      <Tiles/>
      </>
    );
  }
  