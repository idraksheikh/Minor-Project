import React, { useEffect, useState,useCallback } from 'react';
import {Image,Linking,Alert,StyleSheet } from 'react-native';
import { ActivityIndicator, FlatList, Text, View, ScrollView,RefreshControl } from 'react-native';
import { Tile } from 'react-native-elements';
import {TextInput,Button,Card, Title, Paragraph} from "react-native-paper";

import {useDispatch, useSelector} from "react-redux";
import { get_property_info,get_property_info_by_city } from '../../../Slices/sellingSlice';
import validator from "../../../utils/validation";
import {showError} from "../../../utils/dispError";
import imagePath from '../../Constraints/imagePath';



export default function Tiles({match}) {

    const dispatch=useDispatch();
    const [property,setProperty]=useState([]);
    const {selling,status,message}=useSelector((state)=> state.sellingproperty);
    const [city,setCity]=useState('');
    const [vtext,setVtext]=useState(true);
    
   
    const [refreshing, setRefreshing] = useState(false);

    const onRefresh = useCallback(() => {
      setRefreshing(true);
      console.log("refresh");
      wait(2000).then(() => setRefreshing(false));
    }, []);
    
    
 
  const ValidData=()=>{
    const error=validator(
      {
        city
      })
      if(error){
        showError(error);
        return false;
      }
      else{
        return true;
      }
  }
 

  const ValidAndSubmit=()=>{
    
    const checkvalidation=ValidData();
    if(checkvalidation){
     ref();
    }
  }
       
    
    const ref=()=>{
      dispatch(get_property_info_by_city(city));
      
       
  } 
  useEffect(()=>{
    setProperty(selling); 
        
    if(status==="error"){
      alert(message);
      setProperty([]);
      setVtext('Please Enter City');
    }else{
      setVtext(false);
    }
  },[dispatch,message]);
   
    return(
   <View style={styles.containerStyle}>
    <ScrollView contentContainerStyle={styles.scrollViewStyle}> 
    
     <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
          /> 
     <View style={styles.textbox}>
     <TextInput
       mode='flat'
       placeholder='City'
             
       style={styles.inputStyle}         
       value={city}         
       onChangeText={ccity => setCity(ccity)} 
       
     />
      <Button mode="text"  onPress={ValidAndSubmit} > Search</Button>
     </View>
    
     {property && property.map((properties)=>(
       <>
       <Card key={properties._id} style={{margin:5,borderRadius:5,}}>
       <Card.Cover source={{ uri: properties.image.url }} style={{margin:10,borderRadius:10,}} />
        <Card.Content>
        <Title>{properties.location}</Title>
        <Paragraph >{properties.description}</Paragraph>
        <Text > Price :{ properties.price} Lakhs </Text>
      </Card.Content>
     
      <Card.Actions>
      
      <Button  onPress={() => {
            Alert.alert(
            "Email Request",
            "If you want to buy this estate you can send a request mail to the seller.",
            [
              {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel"
              },
              { text: "OK", onPress: () => Linking.openURL(`mailto:${properties.email}?subject=Buying Your Property Request&body=Hello! i want to buy your estate you can contact me using this mail if you are interested.`) }
            ]
          );    
          }}>Buy</Button>
    </Card.Actions>
  </Card>
       
      

        
    </>
    ))} 
    
    {vtext && (<Text style={{alignSelf:'center',marginTop:300,fontSize:20,}}>{vtext}</Text>)}
    </ScrollView>
    </View>   
    
    );
}
const styles = StyleSheet.create({
  containerStyle: {
    flex: 1,
    backgroundColor:'#F3E9DD',  
    
  },
  inputStyle: {
  
  width: 260,
  height: 40,
  paddingHorizontal: 10,
  borderRadius: 5,
  backgroundColor: '#fff',
},
scrollViewStyle: {
  margin:20,  
  padding: 10,
  justifyContent: 'center',
},

textbox:{
  
  flex:1,
  // flexDirection:'row',
  alignItems:'center',
  
},
btn:{
  color:'red',
},
});