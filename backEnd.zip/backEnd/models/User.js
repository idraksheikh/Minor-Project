const mongoose  = require("mongoose");
const bcrypt = require("bcrypt");

const UserSchema=new mongoose.Schema({
    name:{

        type:String,
        required:[true,"Please enter the Name."],
    },
    email:{
        type:String,
        required:[true,"Please enter the Email."],
        unique:[true,"Email already exists."],
    },
    password:{
        type:String,
        required:[true,"Please enter the Password."],
        minlength:[6,"Password must be at 6 characters."],
        select:false,
    },
});

UserSchema.pre('save', async function(next){
    if(!this.isModified('password')){
        next();
    }

    this.password = bcrypt.hash(this.password, 10);
})

module.exports=mongoose.model("User",UserSchema);