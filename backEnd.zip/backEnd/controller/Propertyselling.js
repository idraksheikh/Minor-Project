const Selling=require("../models/Propertyselling")

exports.SellProperty=async(req,res)=>{
    try {
        const {ownername,location,email,contactnumber,description,price,area}=req.body;
        console.log(ownername);
        const newSellProperty={
            ownerName:ownername,
            location:location,
            email:email,
            contactnumber:contactnumber,
            description:description,
            price:price,
            area:area,
            image:image           
        };
        // {ownerName:ownername}

        const newProperty=await Selling.create(newSellProperty);
        
                res.status(201).json({
                    success:true,
                    property:newProperty,
                })

    } catch (error) {
        res.status(500).json({
            success:false
        })
    }
}

exports.getSellProperty = async (req,res) =>{
try {

    const sellProperties = await Selling.find();

    if(!sellProperties){

    }

    res.status(200).json({success:true, sellProperties});

} catch (error) {
    res.status(500).json({
        success:false,
        message : error.message
    })
}

}